module es.um.tds.ProyectoTDS {
    requires javafx.controls;
    requires javafx.fxml;

    opens es.um.tds.ProyectoTDS to javafx.fxml;
    exports es.um.tds.ProyectoTDS;
}
