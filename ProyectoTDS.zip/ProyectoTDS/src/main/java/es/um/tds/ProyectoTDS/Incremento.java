package es.um.tds.ProyectoTDS;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Incremento {
	
	@FXML
	private Label etiqueta;
	
	@FXML
	private void initialize() {
		etiqueta = new Label();
		etiqueta.setText(Integer.toString(0));
	}
	
}
