package es.um.tds.Programa;

import java.util.List;
import java.util.Scanner;

import es.um.tds.Categorias.*;
import es.um.tds.Controlador.AppControlGastos;
import es.um.tds.Usuarios.*;

public class rgsemMain {
	private static final Scanner scanner = new Scanner(System.in);
	private static final AppControlGastos controlador = AppControlGastos.getInstance();

	public static void main(String[] args) {
		System.out.println("-----RGSEM-----");
	    boolean salir = false;
	    while (!salir) {
	    	System.out.print("\nrgsem> ");
	        String input = scanner.nextLine().trim();
	        switch (input) {
	        	case "nuevo-usuario":
	        		comandoNuevoUsuario();
	                break;
	        	case "ver-usuarios":
	                comandoVerUsuarios();
	                break;
	        	case "nueva-categoria":
	        	    comandoNuevaCategoria();
	        	    break;
	        	case "ver-categorias":
	        	    comandoVerCategorias();
	        	    break;
	            case "help":
	                System.out.println("Comandos disponibles: nuevo-usuario, ver-usuarios, nueva-categoria, ver-categorias, exit"); //esto ya lo cambiaré, donde se explique todo y eso
	                break;
	            case "exit":
	                salir = true;
	                break;
	            default:
	                if (!input.isEmpty()) {
	                	System.out.println("Comando no reconocido. Escriba 'help' para ayuda.");                    }
	        }
	    }
	    System.out.println("Saliendo de la aplicación...");
	}

	private static void comandoNuevoUsuario() {
	    while (true) {
	        System.out.print("rgsem> Escriba nombre del usuario. '-show' para lista, '-cancel' para salir: ");
	        String nombre = scanner.nextLine().trim();

	        if (nombre.equalsIgnoreCase("-cancel")) {
	            return;
	        } else if (nombre.equalsIgnoreCase("-show")) {
	            comandoVerUsuarios();
	            continue; 
	        } else if (nombre.isEmpty()) {
	            continue; 
	        }

	        System.out.print("rgsem> Escriba email del usuario. '-cancel' para salir: ");
	        String email = scanner.nextLine().trim();

	        if (email.equalsIgnoreCase("-cancel")) {
	            return;
	        }

	        boolean exito = controlador.crearUsuario(nombre, email);
	        
	        if (exito) {
	            System.out.println("Usuario '" + nombre + "' (" + email + ") creado correctamente.");
	            return;
	        } else {
	            System.out.println("Error: El usuario '" + nombre + "' ya existe.");
	        }
	    }
	}

	    private static void comandoVerUsuarios() {
	        List<Usuario> usuarios = controlador.obtenerUsuarios();
	        if (usuarios.isEmpty()) {
	            System.out.println("(No hay usuarios registrados)");
	        } else {
	            System.out.println("--- Lista de Usuarios ---");
	            for (Usuario u : usuarios) {
	                System.out.println("- " + u.getNombre() + " (" + u.getEmail() + ")");
	            }
	        }
	    }
	    
	    private static void comandoNuevaCategoria() {
	        while (true) {
	            System.out.print("rgsem> Escriba nombre de la categoría. '-show' para lista, '-cancel' para salir: ");
	            String nombre = scanner.nextLine().trim();

	            if (nombre.equalsIgnoreCase("-cancel")) {
	                return;
	            } else if (nombre.equalsIgnoreCase("-show")) {
	                comandoVerCategorias();
	            } else if (!nombre.isEmpty()) {
	                boolean exito = controlador.crearCategoria(nombre);
	                if (exito) {
	                    System.out.println("Categoría '" + nombre + "' creada correctamente.");
	                    return;
	                } else {
	                    System.out.println("Error: La categoría '" + nombre + "' ya existe.");
	                }
	            }
	        }
	    }

	    private static void comandoVerCategorias() {
	        List<Categoria> categorias = controlador.obtenerCategorias();
	        
	        if (categorias == null || categorias.isEmpty()) {
	            System.out.println("No existen categorías registradas.");
	        } else {
	            System.out.println("--- Lista de Categorías ---");
	            for (Categoria c : categorias) {
	                System.out.println("- " + c.getNombre());
	            }
	        }
	    }
	}
