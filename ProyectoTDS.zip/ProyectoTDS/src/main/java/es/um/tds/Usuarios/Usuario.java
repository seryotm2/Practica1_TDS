package es.um.tds.Usuarios;

import java.util.Objects;

public class Usuario {
	private String nombre;
	private String email;
	
	public Usuario() {
	}
	
	public Usuario(String nombre, String email) {
		this.nombre = nombre;
		this.email = email;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return this.nombre + " (email: " + this.email + ")\n";
	}
	
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Objects.equals(nombre, usuario.nombre);
    }
	
	@Override
    public int hashCode() {
        return Objects.hash(nombre);
    }
}
