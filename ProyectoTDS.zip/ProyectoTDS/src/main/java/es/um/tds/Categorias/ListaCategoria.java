package es.um.tds.Categorias;

import java.util.ArrayList;
import java.util.List;

public class ListaCategoria {
    
    private List<Categoria> categorias;

    public ListaCategoria() {
        this.categorias = new ArrayList<>();
    }

    public boolean agregarCategoria(Categoria categoria) {
        if (existeCategoria(categoria.getNombre())) {
            return false;
        }
        this.categorias.add(categoria);
        return true;
    }

    public boolean existeCategoria(String nombre) {
        return categorias.stream()
                .anyMatch(c -> c.getNombre().equalsIgnoreCase(nombre));
    }

    public List<Categoria> getCategorias() {
    	List<Categoria> copia = this.categorias;
        return copia;
    }
    
    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }
}
