package es.um.tds.Usuarios;

import java.util.ArrayList;
import java.util.List;

public class Directorio {
	private List<Usuario> listaUsuarios;
	
	public Directorio() {
        this.listaUsuarios = new ArrayList<>();
    }
	
	public Usuario buscarUsuario(String nombre) {
        return listaUsuarios.stream()
                .filter(u -> u.getNombre().equalsIgnoreCase(nombre))
                .findFirst()
                .orElse(null);
    }
	
	public boolean existeUsuario(String nombre) {
        return buscarUsuario(nombre) != null;
    }
	
	public boolean agregarUsuario(Usuario usuario) {
        if (existeUsuario(usuario.getNombre())) {
            return false; 
        }
        this.listaUsuarios.add(usuario);
        return true;
    }
	
	public List<Usuario> getListaUsuarios() {
		List<Usuario> copia = this.listaUsuarios; //evitar aliasing
        return copia;
    }

    public void setListaUsuarios(List<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
}
