package es.um.tds.Controlador;

import java.util.List;

import es.um.tds.Categorias.*;
import es.um.tds.Usuarios.*;

public class AppControlGastos {

    private static AppControlGastos instance;
    
    private Directorio directorio;
    private ListaCategoria listaCategoria;

    private AppControlGastos() {
        this.directorio = new Directorio();
        this.listaCategoria = new ListaCategoria();
    }

    public static synchronized AppControlGastos getInstance() {
        if (instance == null) {
            instance = new AppControlGastos();
        }
        return instance;
    }

    public boolean crearUsuario(String nombre, String email) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return false;
        }
        Usuario nuevo = new Usuario(nombre, email);
        return directorio.agregarUsuario(nuevo);
    }

    public List<Usuario> obtenerUsuarios() {
        return directorio.getListaUsuarios();
    }
    
    public boolean crearCategoria(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return false;
        }
        return listaCategoria.agregarCategoria(new Categoria(nombre));
    }

    public List<Categoria> obtenerCategorias() {
        return listaCategoria.getCategorias();
    }
}
